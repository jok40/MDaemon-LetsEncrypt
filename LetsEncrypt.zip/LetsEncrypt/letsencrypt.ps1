﻿################################################################################################################################
################################################################################################################################
## Retrieve Certificate from Lets Encrypt  V1.2.1                                                                             ##
## September 18, 2017	     																									      ##
## Copyright Alt-N Technologies	2017												                                          ##
## 	                                                                                                                          ##
## This script is designed to retrieve a certificate from LetsEncrypt and then configure Alt-N's products to use it.  This    ##
## script is only to be used with Alt-N products. The use of this script for any other purpose or with any other products     ##
## is not allowed.                                                                                                            ##
##                                                                                                                            ##
## Alt-N Technologies offers no warranty, provides no support, and is not responsible for any damages that may be arise from  ##
## the use of this script. Use at your own risk.                                                                              ##
##                                                                                                                            ##
################################################################################################################################
################################################################################################################################
#Example usage: .\LetsEncrypt.ps1 -AlternateHostNames mail.domain.com,imap.domain.com,wc.domain.com -IISSiteName MySite -WCIPAddress WorldClientIpAddress -To "admin@yourdomain.com"

param(
    [Parameter(Position = 0)]
    [string[]]$AlternateHostNames,
    [string]$IISSiteName = "WorldClient",
    [string]$WCIPAddress = "",
    [string]$To = ""
    )

$error.clear()
$ErrorActionPreference = "SilentlyContinue"

# if these variables are not in the global namespace, I saw concurrency issues
$global:ErrorSent = ""
$global:LoggedScriptStarting = ""

#This will be used to determine if a restart of MDaemon and all other components is required.
$Restart = $false

#Setting up a global array to store the aliases for Alternate domain names
$global:AlternateHostNameAliases = @()

function Get-PrivateProfileString ($Path, $Category, $Key) {

	#############################################################################
	##
	## Get-PrivateProfileString
	##
	## From Windows PowerShell Cookbook (O'Reilly)
	## by Lee Holmes (http://www.leeholmes.com/guide)
	##
	##############################################################################

	<#

	.SYNOPSIS

	Retrieves an element from a standard .INI file

	.EXAMPLE

	Get-PrivateProfileString c:\windows\system32\tcpmon.ini `
		"<Generic Network Card>" Name
	Generic Network Card

	#>

	Set-StrictMode -Version Latest

	## The signature of the Windows API that retrieves INI
	## settings
	$signature = @'
[DllImport("kernel32.dll")]
public static extern uint GetPrivateProfileString(
   string lpAppName,
   string lpKeyName,
   string lpDefault,
   StringBuilder lpReturnedString,
   uint nSize,
   string lpFileName);
'@

	## Create a new type that lets us access the Windows API function
	$type = Add-Type -MemberDefinition $signature `
		-Name Win32Utils -Namespace GetPrivateProfileString `
		-Using System.Text -PassThru

	## The GetPrivateProfileString function needs a StringBuilder to hold
	## its output. Create one, and then invoke the method
	$builder = New-Object System.Text.StringBuilder 1024
	$null = $type::GetPrivateProfileString($category,
		$key, "", $builder, $builder.Capacity, $path)

	## Return the output
	$builder.ToString()

}

function Write-PrivateProfileString ($Path, $Category, $Key, $Value) {

	Set-StrictMode -Version Latest

	## The signature of the Windows API that retrieves INI
	## settings
	$signature = @'
[DllImport("kernel32.dll")]
public static extern uint WritePrivateProfileString(
   string lpAppName,
   string lpKeyName,
   string lpDefault,
   string lpFileName);
'@

	## Create a new type that lets us access the Windows API function
	$type = Add-Type -MemberDefinition $signature `
		-Name Win32Utils -Namespace WritePrivateProfileString `
		-Using System.Text -PassThru

	## The GetPrivateProfileString function needs a StringBuilder to hold
	## its output. Create one, and then invoke the method
	$builder = New-Object System.Text.StringBuilder 1024
	$null = $type::WritePrivateProfileString($category,
		$key, $value, $path)

	## Return the output
	#$builder.ToString()

}

# Log to console and log file and handle error
function Log($string, $color){
    LogNoError $string $color

    if($string -ne $null)
    {
        if($error -and ($global:ErrorSent -ne "Yes"))
        {
            $error
            $error.clear()

            $global:ErrorSent = "Yes"

            if ($To)
            {
                $EmailBody = $EmailBody + "`r`n`r`n" + $string
                SendEmail $email $To $EmailSubject $EmailBody
            }

            LogNoError "The script is stopping because an error occurred." "Red"

            exit
        }
    }
}

# Only log to console and log file
# Use to allow the script to continue even if an error has occured
function LogNoError($string, $color){
    if($string -ne $null)
    {
        if($global:LoggedScriptStarting -ne "Yes")
        {
            $global:LoggedScriptStarting = "Yes"
            LogNoError "Starting Script run at $MyDate.`r`n"
        }

        if ($color -eq $null)
        {
            $color = "White"
        }

        write-host $string -ForegroundColor $color

        if ($LetsEncryptLog -ne $null)
        {
            $string | out-file -Filepath $LetsEncryptLog -append
        }
    }
}

function SetAlias($Domain, $Alias){
    if($LEXMLContent.LetsEncrypt.Domains.$domain -eq $null)
    {
        Log "Adding the $Domain node."
        $DomainNode = $LEXMLContent.CreateElement($domain)
        $LEXMLContent.SelectSingleNode("//Domains").AppendChild($DomainNode)
        $LEXMLContent.Save($LEXMLPath)
    }
    else
    {
        $DomainNode = $LEXMLContent.SelectSingleNode("//$domain")
    }

    if($LEXMLContent.LetsEncrypt.Domains.$domain.Alias -eq $null)
    {
        Log "Adding $global:Alias as the Alias for $domain."
        $AliasElement = $DomainNode.AppendChild($LEXMLContent.CreateElement("Alias"))
        $AliasTextNode = $AliasElement.AppendChild($LEXMLContent.CreateTextNode($global:Alias))
    }
    else
    {
        Log "Setting the alias for $domain to $Alias"
        $LEXMLContent.LetsEncrypt.Domains.$domain.Alias = $Alias
    }

    $LEXMLContent.Save($LEXMLPath)
}

function CheckAltHostNames ($Alias){
    $certificateInfo = $null

    try
    {
        Log "Checking to see if a certificate already exists for $Alias."
        $certificateInfo = Get-ACMECertificate $Alias -ErrorVariable LogText
    }
    catch
    {
        #TODO: If $error is not cleared here, the next call the Log will see that
        #an error is set and will exit the script
        $error.clear()
        Log $LogText
    }

    if($certificateInfo -ne $null)
    {
        Log "The certificate exists."
        $AltCertNames = $certificateInfo.AlternativeIdentifierDns
        if($AlternateHostNames.Length -eq 0)
        {
            $AlternateHostNames = @()
        }
        if($AltCertNames.Length -eq 0)
        {
            $AltCertNames = @()
        }

        Log "Alternate Host names are $AlternateHostNames"
        Log "AlternativeIdentifierDNS host names are $AltCertNames"

        if(Compare-Object $AlternateHostNames $AltCertNames)
        {
            Log "The list of alternate host names has changed. The alias for the certificate needs to be changed."
            return $true
        }
        else
        {
            Log "The list of alternate host names has not changed."
            return $false
        }
    }
    else
    {
        Log "The certificate doesn't exist."
        return $false
    }
}

function CheckWebScriptingInstalled {

    $WebScriptingInstalled = get-windowsfeature|where{$_.name -eq "Web-Scripting-Tools"}

    Write-Host $WebScriptingInstalled
    if($WebScriptingInstalled.Installed)
    {
        Log "Web Scripting tools are installed."
        Return $true
    }
    elseif(!($WebScriptingInstalled.Installed))
    {
        Log "Error: Web Scripting tools are not installed."
        Return $false
    }
    else
    {
        Log "Error: Unable to determine if the Web Scripting Tools are installed."
        Return $false
    }
}

function SetupDomainforLetsEncrypt($domain, $AltHostName){

    $Identifier = $null

    $global:Alias = $domain + "_Cert" + "_" + $MyYear + "_" + $MyMonth

    $LEXMLPath = join-path $PSScriptRoot "LetsEncrypt.XML"

	if(Test-Path $LEXMLPath)
	{
		Log "Reading configurations from $LEXMLPath."
		[xml]$LEXMLContent = Get-Content -Path $LEXMLPath

		$LENode = $LEXMLContent.SelectSingleNode('//LetsEncrypt')

		#Originally this script did not include a "version" attribute on the LetsEncrypt node.
		#The format of the XML needed to be updated and we included a version node so that in the future we can identify which version of the XML is in use.
		#If the Version Attribute does not exist the file is deleted and recreated.
	    if(!($LENode.Version))
		{
			Write-Host "The version attribute does not exist in $LEXMLPath. The file will be deleted."
			$LEXMLContent = $null
			Remove-Item $LEXMLPath
		}
	}

    if(!(Test-Path $LEXMLPath))
    {

        Log "Creating $LEXMLPath."
        $XMLWriter = New-Object System.XMl.XmlTextWriter($LEXMLPath,$Null)
        $XMLWriter.Formatting = "Indented"
        $XMLWriter.Indentation = "4"
        $XMLWriter.WriteStartDocument()
        $XMLWriter.WriteStartElement("LetsEncrypt")
		$XMLWriter.WriteAttributeString("Version", "1.0")
        $XMLWriter.WriteEndElement
        $XMLWriter.WriteEndDocument()
        $XMLWriter.Finalize
        $XMLWriter.Flush
        $XMLWriter.Close()
    }

    Log "Reading configurations from $LEXMLPath."
    [xml]$LEXMLContent = Get-Content -Path $LEXMLPath

    if(!($LEXMLContent.LetsEncrypt.Domains))
    {
        Log "Creating the Domains node."
        $DomainsNode = $LEXMLContent.CreateElement("Domains")
        $LEXMLContent.SelectSingleNode("//LetsEncrypt").AppendChild($DomainsNode)
        $LEXMLContent.Save($LEXMLPath)
    }

    if($LEXMLContent.LetsEncrypt.Domains.$domain.Alias)
    {
        $XMLAlias = $LEXMLContent.LetsEncrypt.Domains.$Domain.Alias
        Log "The Alias stored in XML is for $Domain is $XMLAlias."

        $YearPOS = $Domain.Length + 6
        $MonthPOS = $YearPOS + 5

        $XMLMonth = $XMLAlias.Substring($MonthPOS,2)
        $XMLYear = $XMLAlias.Substring($YearPOS,4)

		Log "XML Month is $XMLMonth"
        Log "XML Year is $XMLYear"

        if($XMLYear -eq $MYYear)
        {
            if($XMLMonth -lt $MyMonth)
            {
                Log "The Alias stored in XML for $Domain is being updated."
                SetAlias $Domain $global:Alias
            }
            else
            {
                $global:Alias = $XMLAlias
            }
        }
        else
        {
            Log "The Alias stored in XML for $Domain is being updated."
            SetAlias $Domain $global:Alias
        }


        Log "The global:alias is $global:Alias"

        if($AltHostName -eq $false)
        {
            Log "AltHostName is $AltHostName."
            $AltHostNamesChanged = CheckAltHostNames $global:Alias
            if($AltHostNamesChanged -eq $true)
            {
                Log "The list of alternate host names has changed, resetting the alias."
                $global:Alias = $domain + "_Cert" + "_" + $MyYear + "_" + $MyMonth + "_" + $MyTicks
                SetAlias $Domain $global:Alias
            }
        }

    }
    else
    {

        Log "The XML file does not contain an alias for $Domain. It will be added."

        if($AltHostName -eq $false)
        {
            $AltHostNamesChanged = CheckAltHostNames $global:Alias
            if($AltHostNamesChanged -eq $true)
            {
                Log "The list of alternate host names has changed, resetting the alias."
                $global:Alias = $domain + "_Cert" + "_" + $MyYear + "_" + $MyMonth + "_" + $MyTicks
            }
        }

    SetAlias $Domain $global:Alias
    }


    Log "The alias is set to $global:Alias."
    if($AltHostName -eq $true)
    {
        Log "Adding the alias to the AlternateHostNameAliases list"
        $global:AlternateHostNameAliases = $global:AlternateHostNameAliases + $global:Alias
    }

    try
    {
        $Identifier = Get-ACMEIdentifier $global:Alias
    }
    catch
    {
        #TODO: If $error is not cleared here, the next call the Log will see that
        #an error is set and will exit the script
        $error.clear()
    }

    try
    {
        if(((Get-ACMEIdentifier $global:Alias).Challenges | Where-Object { $_.Type -eq 'http-01' })[0].Status -eq "Invalid")
        {
            Log "The current challenge is Invalid. Creating new alias."
            $global:Alias = $domain + "_Cert" + "_" + $MyYear + "_" + $MyMonth + "_" + $MyTicks

            Log "Setting $global:Alias as the Alias for $domain."
            $LEXMLContent.LetsEncrypt.Domains.$domain.Alias = $global:Alias

            $LEXMLContent.Save($LEXMLPath)

            $Identifier = $null
        }
    }
    catch
    {
        #TODO: If $error is not cleared here, the next call the Log will see that
        #an error is set and will exit the script
        $error.clear()
    }

    if($Identifier -eq "" -or $Identifier.Identifier -ne $Domain)
    {
        Log "Setting up new ACME identifier for $domain using $global:Alias."
        $Identifier = New-ACMEIdentifier -Dns $domain -Alias $global:Alias -ErrorVariable LogText
		Log $Identifier
        Log $LogText
    }

	$Identifier = Update-ACMEIdentifier $global:Alias -ErrorVariable LogText
    Log $LogText

	if($Identifier.Status -ne "valid" -or $Identifier.Expires -lt $MyDate)
    {
        Log "Setting up ACME challenge for $domain using $global:Alias."

        $Challenge = Complete-ACMEChallenge $global:Alias -ChallengeType http-01 -Handler manual -ErrorVariable LogText
        Log $LogText

        $Challenge = ((Get-ACMEIdentifier $global:Alias).Challenges | Where-Object { $_.Type -eq 'http-01' })[0].Challenge

        $wellKnownPath = Join-Path $WCHTMLPath ".well-known"
        $AcmeChallengePath = Join-Path $wellKnownPath "Acme-challenge"

        Log "The .well-known path for is $WellKnownPath"
        Log "The Acme Challenge path for $domain is $AcmeChallengePath"

        if(!(Test-Path $wellKnownPath))
        {
            Log "The path $wellKnownPath does not exist, it will be created."
            New-Item $wellKnownPath -type directory
        }
        if(!(Test-Path $AcmeChallengePath))
        {
            Log "The path $AcmeChallengePath does not exist, it will be created."
            New-Item $AcmeChallengePath -type directory
        }

        $ChallengeToken = $Challenge.Token
        $ChallengeContent = $Challenge.FileContent

        if($ChallengeToken -eq $null)
        {
			$Message = "The challenge token is empty for $domain using alias $global:Alias."
			$MessageText = $EmailBody + "`r`n`r`n" + $Message
            Log  $Message "Red"
            Log "This is a critical error, the script will now stop." "Red"

			SendEmail $email $To $EmailSubject $MessageText
			exit
        }
        else
        {
            $ChallengeTokenPath = Join-Path $AcmeChallengePath $ChallengeToken
        }

        Log "The Challenge Token for $domain and alias $global:Alias is $ChallengeToken"
        Log "The Challenge Content for $domain and alias $global:Alias is $ChallengeContent"

        if(Test-Path $ChallengeTokenPath)
        {
            Log "The Challenge Token for $domain and alias $global:Alias already exists, removing file."
            Remove-Item $ChallengeTokenPath
        }

        Log "Creating $ChallengeTokenPath for $domain."
        New-Item -Path $ChallengeTokenPath -type file -value $ChallengeContent -ErrorVariable LogText
        Log $LogText

        Log "Submitting the ACME challenge for $domain and alias $global:Alias for verification."
        $Challenge = Submit-ACMEChallenge $global:Alias -ChallengeType http-01 -ErrorVariable LogText
        Log $LogText

        While ($challenge.Status -eq "pending")
        {
            Start-Sleep -m 500 # wait half a second before trying
            Log "Status is still 'pending' for $domain and $global:Alias, waiting for it to change..."
            #To check status of Challenge:
            #(Update-ACMEIdentifier dns1 -ChallengeType dns-01).Challenges | Where-Object {$_.Type -eq "dns-01"}
            $challenge = Update-ACMEIdentifier $global:Alias -ErrorVariable LogText
            Log $LogText
        }

		if ($challenge.Status -eq "invalid")
		{
			Log $Identifier
			Log "The challenge was not successfully completed. Visit the URI logged above for more information.
				This is a critical error. The script will now exit." "Red"
			exit

		}
    }
    else
    {
        Log "The HTTP challenge for $domain and $global:Alias has already been completed."
    }
}

function SendEmail ($From, $To, $Subject, $Body){
    if($To -eq "")
    {
        Log "Unable to send an error email. No To address was specified."
    }
    else
    {
        $FileNumber = 1
        $RawFile = Join-Path $RAWDir "md50$FileNumber.raw"

        while(Test-Path $RawFile)
        {
            $FileNumber = $FileNumber + 1
            $RawFile = Join-Path $RAWDir "md50$FileNumber.raw"
        }

        $FileContent = "from <$From>`r`nto <$To>`r`nsubject <$Subject>`r`nHeader <Content-Type: text/html>`r`n`r`n$Body"
        New-Item -Path $RawFile -type file -value $FileContent -Force
    }

}

function CreateCertificate(){
    Log "Creating new certificate."

    if($AlternateHostNames.Length -lt 1)
    {
        Log "No alternate host names specified."
        New-ACMECertificate $global:Alias -Alias $global:Alias -Generate -ErrorVariable LogText
    }
    else
    {
        Log "The alternate host names are $AlternateHostNames"
        Log "The alternate host name aliases are $global:AlternateHostNameAliases"
        New-ACMECertificate $global:Alias -Alias $global:Alias -Generate -AlternativeIdentifierRefs $global:AlternateHostNameAliases -ErrorVariable LogText
    }

    Log $LogText

    try
    {
        $certificateInfo = Submit-ACMECertificate $global:Alias
    }
    catch
    {
        #TODO: If $error is not cleared here, the next call the Log will see that
        #an error is set and will exit the script
        $error.clear()
    }


    While([string]::IsNullOrEmpty($certificateInfo.IssuerSerialNumber))
    {
        Start-Sleep -m 500 # wait half a second before trying
        Log "IssuerSerialNumber is not set yet, waiting for it to be populated..."
        $certificateInfo = Update-ACMECertificate $global:Alias -ErrorVariable LogText
        Log $LogText
    }
}

function GetRegistryValue($Key, $Name){

    if(Test-Path $Key)
    {
        $Value = (Get-ItemProperty $Key -Name $Name).$Name
	}

	if(!(Test-Path $Key) -or ($Value -eq $null) -or ($Value.Length -eq 0))
    {

		$Base = Split-Path (Split-Path $Key)
        $Leaf2 = Split-Path $key -Leaf
        $Leaf1 = Split-Path (Split-Path $key) -Leaf

        $SysWownode = Join-Path (Join-Path (Join-Path $Base "Wow6432Node") $Leaf1) $Leaf2

        if(Test-Path $SysWownode)
        {
			Log "The registry key value is empty or does not exist, checking $SysWownode."
            $Value = (Get-ItemProperty $SysWowNode -Name $Name).$Name

            if(($Value -eq $null) -or ($Value.Length -eq 0))
            {
				Log "We can't find the registry key values, the script will now stop."
				exit
            }
            else
            {
				$Error.Clear()
                return $Value
            }
        }
        else
        {
			Log "We can't find the registry key values, the script will now stop."
			exit
        }
    }
    else
    {
		return $Value
    }

}

function Stop-ServiceWithTimeout($Name, $TimeOut){
	$TimeSpan = New-Object -TypeName System.Timespan -ArgumentList 0,0,$TimeOut
	$Service = Get-Service -Name $Name
	if($Service -eq $null)
	{
		return $false
	}

	if($Service.Status -eq [ServiceProcess.ServiceControllerStatus]::Stopped)
	{
		return $true
	}

	$Service.Stop()

	try
	{
		$Service.WaitForStatus([ServiceProcess.ServiceControllerStatus]::Stopped, $TimeSpan)
	}
	catch [ServiceProcess.TimeoutException]
	{
		Log "The $($Service.Name) service did not stop in a timely manner."
		return $false
	}
	return $true
}

$MyDate = Get-Date
$MyYear = $MyDate.Year
$MyMonth = Get-Date -format MM
$MyTicks = $MyDate.Ticks
$ErrorSent = ""
$EmailBody = "An error occurred during the LetsEncrypt process.  The error message is:"
$EmailSubject = "Error Retrieving Certificate"
$CertPassword = $MyTicks

$MDINIPath = GetRegistryValue "HKLM:\SOFTWARE\Alt-N Technologies\MDaemon" "IniPath"
$APPPath = GetRegistryValue "HKLM:\SOFTWARE\Alt-N Technologies\MDaemon" "AppPath"
$WAINIPath = GetRegistryValue "HKLM:\SOFTWARE\Alt-N Technologies\WebAdmin" "SetupFile"
$WAPath = GetRegistryValue "HKLM:\SOFTWARE\Alt-N Technologies\WebAdmin" "Directory"

$MDPath = Split-Path -Path $APPPath -Parent
$PEMPath = Join-Path $MDPath "Pem"
$AirSyncINIPath = Join-Path $MDPath "Data\AirSync.ini"
$WCPath = Join-Path $MDPath "WorldClient"
$WCHTMLPath = Join-Path $WCPath "HTML"
$WCINIPath = Join-Path $WCPath "WorldClient.ini"

$WCRunUnderIIS = Get-PrivateProfileString $WCINIPath "WebServer" "RunUnderIIS"
$WCPort = Get-PrivateProfileString $WCINIPath "WebServer" "Port"
$WCEnabled = Get-PrivateProfileString $MDINIPath "WCServer" "EnableWCServer"
$ASEnabled = Get-PrivateProfileString $AirSyncINIPath "System" "Enable"
$FQDN = Get-PrivateProfileString $MDINIPath "Domain" "FQDN"
$RAWDir = Get-PrivateProfileString $MDINIPath "Directories" "RAW"
$MDLogPath = Get-PrivateProfileString $MDINIPath "Directories" "LogFiles"

$email = "postmaster@"+$FQDN

$LetsEncryptLog = Join-Path $MDLogPath "LetsEncrypt.log"

if(Test-Path $LetsEncryptLog)
{
    Log "Removing the log from $LetsEncryptLog"
    Remove-Item $LetsEncryptLog
}

Log "Starting Script run at $MyDate."
Log "Get the MDaemon paths."
Log "The MDaemon.ini Path is $MDINIPath."
Log "The MDaemon APP Path is $APPPath."
Log "The MDaemon Pem path is $PEMPath."
Log "The MDaemon Log path is $MDLogPath."
Log "The MDaemon RAW path is $RAWDir."
Log "The WorldClient Path is $WCPath."
Log "The WorldClient HTML Path is $WCHTMLPath."
Log "The FQDN is set to $FQDN."
Log "The email address is set to $email."
Log "Importing the ACMESharp module."

#if($WCEnabled -eq "No")
#{
#    $Message = "Error: WorldClient must be enabled. This script will stop now."
#	$MessageText = $EmailBody + "`r`n`r`n" + $Message
#    Log  $Message "Red"
#    Log "This is a critical error, the script will now stop." "Red"

#	SendEmail $email $To $EmailSubject $MessageText

#    Exit
#}

if($WCRunUnderIIS -ne "Yes" -and $WCPort -ne "80" -and $ASEnabled -ne "Yes")
{
	$Message = "Error: WorldClient must be listening on port 80. This script will stop now."
	$MessageText = $EmailBody + "`r`n`r`n" + $Message
    Log  $Message "Red"
    Log "This is a critical error, the script will now stop." "Red"

	SendEmail $email $To $EmailSubject $MessageText

    Exit
}


Import-Module ACMESharp -ErrorVariable LogText
Log $LogText

#FYI - this is where the vault is created:
#Running as Admin: C:\ProgramData\ACMESharp\sysVault
#Running as User:  C:\Users\NAME\AppData\Local\ACMESharp\userVault

if(!(Get-ACMEVault))
{
    Log "Initializing ACME Vault."
    #Initialize-ACMEVault -ErrorVariable LogText
    Initialize-ACMEVault -BaseURI https://acme-staging.api.letsencrypt.org/ -ErrorVariable LogText
    Log $LogText
}
else
{
    Log "The ACME Vault is already setup."
}

$Registration = $null

try
{
    $Registration = Get-ACMERegistration
}
catch
{
    #TODO: If $error is not cleared here, the next call the Log will see that
    #an error is set and will exit the script
    $error.clear()
}

if($Registration -eq $null -or $Registration.Contacts -notcontains "mailto:$email")
{
    Log "Setting up new ACME registration."
    $Registration = New-ACMERegistration -Contacts mailto:$email -AcceptTos -ErrorVariable LogText
	Log $Registration
    Log $LogText
}
else
{
    Log "The ACME registration is already setup."
}

#This is necessary for any alternate host names to work.
foreach($AltHostName in $AlternateHostNames)
{
    Log "Setting up $AltHostName."
    SetupDomainforLetsEncrypt $AltHostName $true
}

Log "Setting up $FQDN."
SetupDomainforLetsEncrypt $FQDN $false

$CertFileName = "$global:Alias.pfx"
$CertOutput = Join-Path $PEMPath $CertFileName

$Challenge = Get-ACMEIdentifier $global:Alias -ErrorVariable LogText

if($Challenge.Status -eq "valid")
{
    $certificateInfo = $null

    # try to get the existing certificate from the vault
    # if an error occurs, a new certificate will be created
    try
    {
        Log "Checking to see if a certificate already exists for $global:Alias."
        $certificateInfo = Get-ACMECertificate $global:Alias -ErrorVariable LogText
    }
    catch
    {
        #TODO: If $error is not cleared here, the next call the Log will see that
        #an error is set and will exit the script
        $error.clear()
        Log $LogText
    }


    if($certificateInfo -eq $null)
    {
        Log "No certificate was found for $global:Alias."
        CreateCertificate
    }

    if(Test-Path $CertOutput)
    {
        Log "$CertOutput already exists, it will be deleted."
        Remove-Item $CertOutput
    }

    Log "Downloading Certificate."

    $certificateInfo = Get-ACMECertificate $global:Alias -ExportPkcs12 $CertOutput -CertificatePassword $CertPassword -ErrorVariable LogText
    Log $LogText

    Log "All done, there's a pfx file at $CertOutput."
}
Else
{
    if($WCRunUnderIIS -eq "Yes")
    {
        $message = "Status is '{0}', can't continue as it is not 'valid'. Most likely because IIS is not configured to handle extensionless static files.
        Here is one way to fix that:
        1. Goto Site/Server->Mime Types
        2. Add a mime type of .* (text/plain)
        3. Goto Site/Server->Handler Mappings->View Ordered List
        4. Move the StaticFile mapping above the ExtensionlessUrlHandler mappings.
        Before making any changes, you should understand the security implications of doing so." -f $challenge.Status
    }
    else
    {
        $message = "Status is '{0}', can't continue as it is not 'valid'." -f $challenge.Status
    }
	Log $Challenge
    Log $message
    Exit
}

$ThumbPrint = $certificateInfo.Thumbprint

#This adds a space after every 4th character. This is how MD writes out the thumbprint and is needed so that we can correctly compare the values.
$Thumbprint = $Thumbprint -replace '(....(?!$))','$1 '

#Get the current certificate hash from the MDaemon.ini file so we can compare them.
$MDCertificateHash = Get-PrivateProfileString $MDINIPath "SSL" "CertificateHash"

if($MDCertificateHash -ne $ThumbPrint)
{
	#Import the cert into Windows... This is only done if the MDaemon.ini file is not already using the certificate.
	$Arguments = "-f -p $CertPassword -importpfx ""$CertOutput"""

	Log "Importing the certificate"
	$ImportResults = Start-Process "certutil.exe" -ArgumentList $Arguments -Wait -PassThru -ErrorVariable LogText
	Log $LogText

	if($ImportResults.ExitCode -ne 0)
	{
		$Message = "The certificate could not be imported.  Check the log at $LetsEncryptLog for more information."
		$MessageText = $EmailBody + "`r`n`r`n" + $Message
		Log  $Message "Red"
		Log "This is a critical error, the script will now stop." "Red"

		SendEmail $email $To $EmailSubject $MessageText

		exit
	}

	#Configure MDaemon to use it and reload the settings.

	Log "Setting the certificate hash value in the MDaemon.ini file to $ThumbPrint."
	Write-PrivateProfileSTring $MDINIPath "SSL" "CertificateHash" $Thumbprint
	Write-PrivateProfileSTring $MDINIPath "SSL" "CertStoreLocation" "LocalMachine"
	Write-PrivateProfileSTring $MDINIPath "SSL" "CertStoreName" "My"

	#Setting this so that MDaemon will be restarted.
	$Restart = $true
}
else
{
	Log "MDaemon is already configured to use $Thumbprint as the certificate hash."
	Log "The MDaemon.ini file will not be updated."
}



if($WCRunUnderIIS -eq "Yes")
{
    Log "WorldClient is configured to run under IIS."

    if(CheckWebScriptingInstalled)
    {
        Log "The web scripting tools are installed."

        if($IISSiteName -eq "")
        {
            Log "Error: No IIS website name specified."
        }
        else
        {
            Log "Importing the AcmeSharp-IIS module."

            Import-Module AcmeSharp\AcmeSharp-IIS -ErrorVariable LogText
            Log $LogText

            Log "Configuring the $IISSiteName website in IIS to use $Thumbprint."

            if($WCIPAddress -eq "")
            {
              Install-ACMECertificateToIIS -Certificate $Global:Alias -WebSite $IISSiteName -Replace -ErrorVariable LogText
            }
            else
            {
              Install-ACMECertificateToIIS -Certificate $Global:Alias -WebSite $IISSiteName -IPAddress $WCIPAddress -Replace -ErrorVariable LogText
            }

            Log $LogText
        }
    }
    else
    {
        Log "Error: Cannot configure the IIS website. The Microsoft Web Scripting Tools are not installed."
    }

}
else
{
	$WCCertificateHash = Get-PrivateProfileString $WCINIPath "SSL" "CertificateHash"
	if($WCCertificateHash -ne $ThumbPrint)
	{
		Log "Setting the certificate hash value in the $WCINIPath file to $ThumbPrint."

		Write-PrivateProfileString $WCINIPath "SSL" "CertificateHash" $Thumbprint
		Write-PrivateProfileString $WCINIPath "SSL" "CertStoreLocation" "LocalMachine"
		Write-PrivateProfileString $WCINIPath "SSL" "CertStoreName" "My"

		$Restart = $true
	}
	else
	{
		Log "WorldClient is already configured to use $Thumbprint as the certificate hash."
		Log "The WorldClient.ini file will not be updated."
	}
}

$WARunUnderIIS = Get-PrivateProfileString $WAINIPath "WebServer" "RunUnderIIS"

if($WARunUnderIIS -eq "Yes")
{
    Log "MDaemon Remote Administration is configured to run under IIS."
    #Check to see if web scripting tools are installed.

    if(CheckWebScriptingInstalled)
    {
        Log "The web scripting tools are installed."

        if($IISSiteName -eq "")
        {
            Log "Error: No IIS website name specified."
        }
        else
        {
            Log "Importing the AcmeSharp-IIS module."

            Import-Module AcmeSharp\AcmeSharp-IIS -ErrorVariable LogText
            Log $LogText

            Log "Configuring the $IISSiteName website in IIS to use $Thumbprint."
            Install-ACMECertificateToIIS -Certificate $global:Alias -WebSite $IISSiteName -Replace -ErrorVariable LogText
            Log $LogText
        }
    }
    else
    {
        Log "Error: Cannot configure the IIS website. The Microsoft Web Scripting Tools are not installed."
    }
}
else
{
	$WACertificateHash = Get-PrivateProfileString $WAINIPath "SSL" "CertificateHash"
	if($WACertificateHash -ne $ThumbPrint)
	{
		Log "Setting the certificate hash value in the $WAINIPath file to $ThumbPrint."

		Write-PrivateProfileSTring $WAINIPath "SSL" "CertificateHash" $Thumbprint
		Write-PrivateProfileSTring $WAINIPath "SSL" "CertStoreLocation" "LocalMachine"
		Write-PrivateProfileSTring $WAINIPath "SSL" "CertStoreName" "My"

		$Restart = $true
	}
	else
	{
		Log "MDaemon Remote Administration is already configured to use $Thumbprint as the certificate hash."
		Log "The WebAdmin.ini file will not be updated."
	}
}

if($Restart)
{
	Log "Stopping MDaemon..."
	if(Stop-ServiceWithTimeout MDaemon 120)
	{
		Log "The MDaemon service has stopped."
	}
	else
	{
		$Message = "The MDaemon service did not stop in a timely manner. MDaemon needs to be manually restarted."
		$MessageText = $EmailBody + "`r`n`r`n" + $Message
		Log  $Message "Red"
		Log "This is a critical error, the script will now stop." "Red"

		SendEmail $email $To $EmailSubject $MessageText
	}

	$WAEnabled = Get-PrivateProfileString $MDINIPath "WebAdmin" "EnableWebAdmin"
	$StopWA = Get-PrivateProfileSTring $MDINIPath "WebAdmin" "StopWebAdminWithMDaemon"

	if($StopWA -ne "Yes" -and $WARunUnderIIS -ne "Yes" -and $WAEnabled -ne "No")
	{
		if(Stop-ServiceWithTimeout WebAdmin 120)
		{
			Log "The MDaemon Remote Administration service has stopped."
		}
		else
		{
			$Message = "The MDaemon Remote Administration service did not stop in a timely manner. MDaemon RemoteAdministration needs to be manually restarted."
			$MessageText = $EmailBody + "`r`n`r`n" + $Message
			Log  $Message "Red"
			Log "This is a critical error, the script will now stop." "Red"

			SendEmail $email $To $EmailSubject $MessageText
		}
	}

	Log "Starting MDaemon..."
	Start-Service -Name MDaemon -ErrorVariable LogText
	Log $LogText

	if($StopWA -ne "Yes" -and $WARunUnderIIS -ne "Yes" -and $WAEnabled -ne "No")
	{
		Log "Starting MDaemon Remote Administration."
		Start-Service -Name WebAdmin -ErrorVariable LogText
		Log $LogText
	}
}
else
{
	Log "No INI files were updated. No restart is required."
	Log "The script will now end."
}
